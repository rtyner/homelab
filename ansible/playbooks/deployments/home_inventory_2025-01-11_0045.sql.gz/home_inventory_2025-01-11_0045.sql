--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Ubuntu 17.2-1.pgdg24.04+1)
-- Dumped by pg_dump version 17.2 (Ubuntu 17.2-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: generate_file_path(integer, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generate_file_path(item_id integer, file_type text, file_extension text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    CASE 
        WHEN file_type = 'picture' THEN
            RETURN '/opt/inventory/pictures/' || item_id::TEXT || '.' || file_extension;
        WHEN file_type = 'invoice' THEN
            RETURN '/opt/inventory/invoices/' || item_id::TEXT || '.' || file_extension;
        ELSE
            RAISE EXCEPTION 'Invalid file type: %', file_type;
    END CASE;
END;
$$;


ALTER FUNCTION public.generate_file_path(item_id integer, file_type text, file_extension text) OWNER TO postgres;

--
-- Name: get_items_missing_files(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_items_missing_files(p_file_type text) RETURNS TABLE(id integer, item_name text, category text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT i.id, i.item_name::TEXT, i.category::TEXT
    FROM inventory i
    WHERE CASE 
        WHEN p_file_type = 'picture' THEN picture_path IS NULL
        WHEN p_file_type = 'invoice' THEN invoice_path IS NULL
        ELSE FALSE
    END;
END;
$$;


ALTER FUNCTION public.get_items_missing_files(p_file_type text) OWNER TO postgres;

--
-- Name: set_invoice_path(integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_invoice_path(p_id integer, p_path text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE inventory SET invoice_path = p_path WHERE id = p_id;
END;
$$;


ALTER FUNCTION public.set_invoice_path(p_id integer, p_path text) OWNER TO postgres;

--
-- Name: set_picture_path(integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_picture_path(p_id integer, p_path text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE inventory SET picture_path = p_path WHERE id = p_id;
END;
$$;


ALTER FUNCTION public.set_picture_path(p_id integer, p_path text) OWNER TO postgres;

--
-- Name: update_file_path(integer, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_file_path(p_item_id integer, p_file_type text, p_file_extension text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_path TEXT;
BEGIN
    -- Validate the file extension
    IF NOT validate_file_extension(p_file_type, p_file_extension) THEN
        RAISE EXCEPTION 'Invalid file extension: % for file type: %', p_file_extension, p_file_type;
    END IF;

    -- Generate the new path
    new_path := generate_file_path(p_item_id, p_file_type, p_file_extension);

    -- Update the appropriate column
    IF p_file_type = 'picture' THEN
        UPDATE inventory SET picture_path = new_path WHERE id = p_item_id;
    ELSIF p_file_type = 'invoice' THEN
        UPDATE inventory SET invoice_path = new_path WHERE id = p_item_id;
    END IF;

    RETURN new_path;
END;
$$;


ALTER FUNCTION public.update_file_path(p_item_id integer, p_file_type text, p_file_extension text) OWNER TO postgres;

--
-- Name: validate_file_extension(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validate_file_extension(file_type text, file_extension text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF file_type = 'picture' THEN
        RETURN file_extension = ANY(ARRAY['jpg', 'jpeg', 'png']);
    ELSIF file_type = 'invoice' THEN
        RETURN file_extension = ANY(ARRAY['pdf', 'doc', 'docx']);
    ELSE
        RETURN FALSE;
    END IF;
END;
$$;


ALTER FUNCTION public.validate_file_extension(file_type text, file_extension text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    item_name character varying(100) NOT NULL,
    model character varying(100),
    serial_number character varying(100),
    purchase_price numeric(10,2),
    current_value numeric(10,2),
    date_purchased date,
    vendor character varying(100),
    count integer DEFAULT 1,
    notes text,
    category character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    picture_path character varying(512),
    invoice_path character varying(512),
    brand_name character varying(100),
    purchase_method character varying(100),
    business_expense boolean DEFAULT false NOT NULL
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_files; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.inventory_files AS
 SELECT id,
    item_name,
    category,
        CASE
            WHEN (picture_path IS NOT NULL) THEN true
            ELSE false
        END AS has_picture,
        CASE
            WHEN (invoice_path IS NOT NULL) THEN true
            ELSE false
        END AS has_invoice,
    picture_path,
    invoice_path
   FROM public.inventory;


ALTER VIEW public.inventory_files OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, item_name, model, serial_number, purchase_price, current_value, date_purchased, vendor, count, notes, category, created_at, picture_path, invoice_path, brand_name, purchase_method, business_expense) FROM stdin;
68	Adidas Stan Smith White	Stan Smith	\N	100.00	\N	\N	Finish Line	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Adidas	\N	f
61	Allen Edmonds Higgins Mill	Higgins Mill	\N	400.00	\N	\N	Goodwill	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Allen Edmonds	\N	f
60	Allen Edmonds Park Avenue Walnut	Park Avenue	\N	350.00	\N	\N	Goodwill	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Allen Edmonds	\N	f
59	Allen Edmonds Strand Walnut	Strand	\N	350.00	\N	\N	Allen Edmonds	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Allen Edmonds	\N	f
14	Apple TV 4k	\N	\N	\N	\N	\N	Amazon	2	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	t
69	Meermin Suede Brown Belt	\N	\N	75.00	\N	\N	Meermin	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Meermin	\N	f
67	Chippewa LLBean Boots	\N	\N	200.00	\N	\N	LLBean	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	LL Bean	\N	f
65	New Balance 530	\N	\N	150.00	\N	\N		1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	New Balance	\N	f
2	Nintendo Switch Pro Controller	\N	\N	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Nintendo	\N	f
36	Samsung 850 EVO	250GB	\N	\N	\N	\N	Amazon	1	SATA SSD	Electronics	2024-12-19 02:56:03.547032	\N	\N	Samsung	\N	f
52	StarTech 12U	\N	\N	\N	\N	\N	Amazon	1	19" Open Frame Server Rack	Electronics	2024-12-19 02:56:03.547032	\N	\N	StarTech	\N	f
5	MacBook Pro	Mid 2014	\N	\N	\N	\N	eBay	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	t
149	Samsumg 870 EVO	1TB	S6PTNM0T316068V	\N	\N	\N	Amazon	1	SATA SSD, prod-pve-01	Electronics	2024-12-23 02:09:26.155273	\N	\N	Samsung	\N	f
41	FX888D29BY/P	\N	\N	\N	\N	\N	\N	1	Soldering Station	Electronics	2024-12-19 02:56:03.547032	\N	\N	Hakko	\N	f
44	ROG Crosshair VII Hero	X470	\N	\N	\N	\N	\N	1	Motherboard	Electronics	2024-12-19 02:56:03.547032	\N	\N	ASUS	\N	t
45	Ryzen 7	2700X	\N	\N	\N	\N	\N	1	3.7GHz CPU	Electronics	2024-12-19 02:56:03.547032	\N	\N	AMD	\N	t
50	Kraken Water Cooler	X62	\N	\N	\N	\N	\N	1	AIO Liquid CPU Cooler	Electronics	2024-12-19 02:56:03.547032	\N	\N	NZXT	\N	t
11	iPhone 15	Pro Max	\N	\N	\N	\N	Apple	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	t
12	AirPods	Gen 1	\N	\N	\N	\N	\N	2	One gift from ITW	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	t
9	Apple Pencil		\N	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	t
8	Apple iPad Air	\N	\N	\N	\N	\N	Apple	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	t
54	Cisco WS-C3560G-24PS-S	WS-C3560G-24PS-S	\N	\N	\N	\N	eBay	1	24 Port POE Gigabit Switch	Electronics	2024-12-19 02:56:03.547032	\N	\N	Cisco	\N	t
32	Poweredge Server	R720	\N	\N	\N	\N	eBay	1	192GB RAM	Electronics	2024-12-19 02:56:03.547032	\N	\N	Dell	\N	t
29	TP-Link PoE Injector	TL-PoE170S	\N	\N	\N	\N	Amazon	1	Gigabit PoE Injector	Electronics	2024-12-19 02:56:03.547032	\N	\N	TP-Link	\N	t
22	Keychron K8 Wireless Mechanical Keyboard	\N	\N	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Keychron	\N	t
24	Logitech G502 Lightspeed	\N	\N	\N	\N	\N	Amazon	1	Wireless Gaming Mouse	Electronics	2024-12-19 02:56:03.547032	\N	\N	Logitech	\N	t
25	Logitech G600	\N	\N	\N	\N	\N	Amazon	1	MMO Gaming Mouse	Electronics	2024-12-19 02:56:03.547032	\N	\N	Logitech	\N	t
26	Logitech K400 Plus	\N	\N	\N	\N	\N	Amazon	1	Wireless Keyboard	Electronics	2024-12-19 02:56:03.547032	\N	\N	Logitech	\N	t
23	Logitech G Pro Wireless Gaming Mouse	\N	\N	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Logitech	\N	t
142	Vortex SPARC AR Red Dot	SPC-AR1	\N	127.98	\N	2019-05-12	Sportman's Outdoor	1	\N	Firearms	2024-12-18 23:22:56.77626	\N	\N	Vortex	\N	f
18	Steelseries Arctis 9	\N	\N	\N	\N	\N	Amazon	1	Dual Wireless Gaming Headphones	Electronics	2024-12-19 02:56:03.547032	\N	\N	Steelseries	\N	f
27	eufy Robot Vacuum	B3	\N	\N	\N	\N	Amazon	1	Robot Vacuum	Electronics	2024-12-19 02:56:03.547032	\N	\N	Anker	\N	f
13	Apple AirPods Pro	Gen 1	\N	\N	\N	\N	eBay	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	f
46	Radeon Graphics Card	RX6400	\N	0.00	\N	\N	Bryan Lurer	1	Graphics Card	Electronics	2024-12-19 02:56:03.547032	\N	\N	AMD	\N	f
38	Western Digital WD Red Pro	14TB	\N	\N	\N	\N		1	NAS HDD	Electronics	2024-12-19 02:56:03.547032	\N	\N	Western Digital	\N	f
62	Allen Edmonds Slip On	\N	\N	150.00	\N	\N	Goodwill	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Allen Edmonds	\N	f
43	Hot Air Rework Station	858D	\N	\N	\N	\N	Amazon	1	Soldering Hot Air Rework Station	Electronics	2024-12-19 02:56:03.547032	\N	\N	CREWORKS	\N	f
56	Zojirushi NS-TSC10		\N	\N	\N	\N	Amazon	1	5-1/2 Cup Micom Rice Cooker	Appliances	2024-12-19 02:56:03.547032	\N	\N	Zojirushi	\N	f
10	Apple Watch	Series 3 Stainless Steel	\N	\N	\N	\N	John Shamp	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	f
39	Western Digital WD Red	8TB	\N	\N	\N	\N	\N	1	NAS HDD	Electronics	2024-12-19 02:56:03.547032	\N	\N	Western Digital	\N	t
64	Made in Italy Calfskin White Sneakers	\N	\N	350.00	\N	\N	PT Man Zurich	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Camerlengo	\N	f
71	Leather Woven Belt	\N	\N	100.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Coach	\N	f
72	Zegna 5 Pocket Pants Cotton Olive	\N	\N	25.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Zegna	\N	f
73	Zegna 5 Pocket Pants Wool Cashmere Gray	\N	\N	25.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Zegna	\N	f
66	Greats Slip On	\N	\N	\N	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Greats	\N	f
58	Electric Conical Burr Coffee Grinder	\N	\N	\N	\N	\N	Amazon	1	Stainless Steel 19 Settings	Electronics	2024-12-19 02:56:03.547032	\N	\N	\N	\N	f
75	Zanella High Waisted Pleated Trousers Charcoal	\N	\N	30.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Zanella	\N	f
63	Meermin Suede Loafers	\N	\N	200.00	\N	\N	Meermin	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Meermin	\N	f
70	Meermin Suede Taupe Belt	\N	\N	75.00	\N	\N	Meermin	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Meermin	\N	f
74	Zanella Wool Trousers Checked Blue	\N	\N	30.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Zanella	\N	f
34	Samsung 960 EVO	500GB	\N	\N	\N	\N	Amazon	1	M.2 NVMe SSD	Electronics	2024-12-19 02:56:03.547032	\N	\N	Samsung	\N	f
20	WASDv2 Mechanical Keyboard	Cherry MX Brown	\N	150.00	\N	\N	WASD	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	WASD	\N	f
31	Ubiquity Unifi AP-AC-Lite	\N	\N	\N	\N	\N	Amazon	1	Wireless Access Point	Electronics	2024-12-19 02:56:03.547032	\N	\N	Ubiquity	\N	f
30	Ubiquity Unifi Security Gateway	USG	\N	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Ubiquity	\N	f
51	Computer Case	Define R6	\N	\N	\N	\N	\N	1	Full Tower Computer Case	Electronics	2024-12-19 02:56:03.547032	\N	\N	Fractal Design	\N	t
3	ThinkPad Laptop	T480s	\N	\N	\N	\N	eBay	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Lenovo	\N	t
4	ThinkPad Laptop	T470	\N	\N	\N	\N	eBay	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Lenovo	\N	f
42	FX8801	\N	\N	\N	\N	\N	\N	1	Soldering Iron	Electronics	2024-12-19 02:56:03.547032	\N	\N	HAKKO	\N	f
55	HP ProLiant Tower Server	ML310E	\N	300.00	\N	\N	Net-Man, Inc.	1	Purchased from James, former Terri Lobb server	Electronics	2024-12-19 02:56:03.547032	\N	\N	HP	\N	f
37	Samsung 850 EVO	500GB	S21HNSAG145442E	\N	\N	\N	Amazon	1	SATA SSD	Electronics	2024-12-19 02:56:03.547032	\N	\N	Samsung	\N	f
57	Thermal Coffee Maker	BVMC-PSTX91-RB	\N	\N	\N	\N	\N	1	10-Cup Thermal Coffeemaker	Electronics	2024-12-19 02:56:03.547032	\N	\N	Mr. Coffee	\N	f
35	Samsung 870 EVO	1TB	S6PTNM0T314944V	\N	\N	\N	Amazon	1	SATA SSD, prod-pve-01	Electronics	2024-12-19 02:56:03.547032	\N	\N	Samsung	\N	f
140	Apple Air Pods Pro	Gen 2	\N	189.99	\N	2024-06-23	Amazon	1	\N	Electronics	2024-12-18 22:39:34.803848	\N	\N	Apple	\N	t
92	Spier and Mackay Blue & Off-White Stripe Lightweight Oxford Shirt	\N	\N	58.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
141	Aero Precision M4E1 AR15 Complete Upper Receiver	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-18 23:16:20.322477	\N	\N	Aero Precision	\N	f
94	Spier and Mackay Charcoal Chino	\N	\N	68.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
93	Spier and Mackay Cream Polo	\N	\N	58.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
89	Zegna Microtine Brown Rain Jacket	\N	\N	100.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Zegna	\N	f
87	Zegna Navy Checked Wool Scarf	\N	\N	40.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Zegna	\N	f
143	Trident Z RGB Series Memory	F4-3600C18D-32GTZR)	\N	67.49	\N	2024-11-25	Amazon	1	32GB (2x16GB) DDR4 RAM Kit	Electronics	2024-12-19 02:56:03.547032	\N	\N	G.Skill	\N	f
97	Spier and Mackay Gray Short Sleeve Polo Shirt Collar	\N	\N	38.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
90	Spier and Mackay Light Brown Pique Polo	\N	\N	48.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
98	Spier and Mackay Navy Chino	\N	\N	68.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
91	Spier and Mackay Olive Green Pique Polo	\N	\N	48.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
99	Spier and Mackay Olive High Rise	\N	\N	68.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
100	Spier and Mackay Storm Blue Short Sleeve Polo Shirt Collar	\N	\N	38.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
19	ModMic 5	\N	\N	\N	\N	\N	Amazon	1	Modular Attachable Boom Microphone	Electronics	2024-12-19 02:56:03.547032	\N	\N	Antillion Audio	\N	f
82	Brioni Roma Navy Checked Blazer	\N	\N	1500.00	\N	\N	Goodwill	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Brioni	\N	f
79	LBM 1911 Tailored Fit Dandy Jacket Wool	\N	\N	800.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	LBM	\N	f
127	Early 1900s Antique Burl Walnut Writing Desk	\N	\N	325.00	\N	\N	The Barn Antique	1	\N	Furniture	2024-12-19 03:18:56.629966	\N	\N	\N	\N	f
81	LBM Navy Blazer	\N	\N	800.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	LBM	\N	f
78	Meyer Taupe Trousers	\N	\N	200.00	\N	\N	Germany	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Meyer	\N	f
112	NC Star Range Bag	\N	\N	\N	\N	\N	Amazon	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	NC Star	\N	f
132	Antique Danish Mid Century Modern Dining Set	Teak	\N	1337.00	\N	\N	The Barn Antiques	1	\N	Furniture	2024-12-19 03:18:56.629966	\N	\N	\N	\N	f
86	No Starch Blue OCBD	\N	\N	75.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	No Starch	\N	f
83	Paul Stuart Virgin Wool Thigh Length Camel Coat	\N	\N	1200.00	\N	\N	Goodwill	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Paul Stuart	\N	f
113	Savior Equipment Urban Double Carbine Long Rifle Gun Case	\N	\N	\N	\N	\N	Amazon	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Savior	\N	f
111	T.REX Light-Compatible Ragnarok Holster	\N	\N	\N	\N	\N	T.REX Arms	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	T.REX Arms	\N	f
88	The Mens Shop Cashmere Leather Gloves	\N	\N	200.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	The Mens Shop	\N	f
106	CZ SP-01 Phantom 9mm	\N	C425828	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	CZ	\N	f
107	CZ SP-01 Phantom OEM 20 Round Magazine	\N	\N	\N	\N	\N	\N	2	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	CZ	\N	f
108	Remington 870 12ga Shotgun	\N	AB767142M	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Remington	\N	f
110	Streamlight 69260 TLR-1 GL Weapon Mount Light	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Streamlight	\N	f
114	Magpul MOE Carbine Stock Gray	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Magpul	\N	f
116	Radian Raptor AR15 Charging Handle	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Radian	\N	f
117	Streamlight ProTac HL-X	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Streamlight	\N	f
120	HOLOSUN - HS510C Reflex Red Dot Sight	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Holosun	\N	f
129	Herman Miller Aeron Size B Ergonomic Office Chair	\N	\N	0.00	\N	\N	\N	1	Gift from mom and michael	Furniture	2024-12-19 03:18:56.629966	\N	\N	Herman Miller	\N	f
1	Nintendo Switch	Gen 1	\N	299.00	\N	2018-10-01	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Nintendo	\N	f
122	Cloud Defensive, LCS	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Cloud Defensive	\N	f
124	Mossberg Plinkster .22 Rifle	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Mossberg	\N	f
48	ASUS DRW-24F1ST	\N	\N	\N	\N	\N	Amazon	1	DVD SATA Disk Drive	Electronics	2024-12-19 02:56:03.547032	\N	\N	ASUS	\N	f
102	Aero Precision M4E1 AR15 Complete Lower Receiver	\N	M4-0087101	215.23	\N	2019-05-18	Aero Precision	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Aero Precision	\N	f
115	Magpul MOE Grip Gray	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Magpul	\N	f
118	Magpul MVG MLOK Vertical Grip	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Magpul	\N	f
121	Blue Force Gear Padded Vickers 2 to 1 Sling	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Blue Force Gear	\N	f
123	Arisaka Defense Offset Scout Flashlight Mount	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Arisaka Defense	\N	f
131	Alontay 2 Drawer Nightstand by Union Rustic	Walnut	\N	254.00	\N	\N	Wayfair	1	\N	Furniture	2024-12-19 03:18:56.629966	\N	\N	Alontay	\N	f
133	Raine Low Profile Platform Bed by Steelside King	Walnut	\N	715.00	\N	\N	Wayfair	1	\N	Furniture	2024-12-19 03:18:56.629966	\N	\N	Raine	\N	f
134	Project 62 72" 5 Shelf Loring Laffer Bookshelf	Walnut	\N	150.00	\N	\N	Target	1	\N	Furniture	2024-12-19 03:18:56.629966	\N	\N	Project 62	\N	f
135	Gibson SG	\N	\N	1000.00	\N	\N	Jack Duncan	1	\N	Guitars	2024-12-19 03:35:52.936752	\N	\N	Gibson	\N	f
136	Epiphone Les Paul	\N	\N	600.00	\N	\N	Guitar Center	1	\N	Guitars	2024-12-19 03:35:52.936752	\N	\N	Epiphone	\N	f
138	Fender Stratocaster	\N	\N	400.00	\N	\N	Guitar Center	1	\N	Guitars	2024-12-19 03:35:52.936752	\N	\N	Fender	\N	f
139	Fender Telecaster	\N	\N	600.00	\N	\N	Muscians Friend	1	\N	Guitars	2024-12-19 03:35:52.936752	\N	\N	Fender	\N	f
16	LG OLED C1 Series 55"	OLED55C1PUB 2021	\N	1173.78	\N	2022-07-09	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	LG	\N	f
126	Heywood Wakefield Nesting Table Set - Antique	Teak	\N	0.00	250.00	\N	\N	1	Gift from my mom	Furniture	2024-12-19 03:18:56.629966	\N	\N	Heywood Wakefield	\N	f
128	Noah Dark Gray Fabric Sofa	Noah	\N	1189.94	\N	2022-07-24	City Furniture	1	\N	Furniture	2024-12-19 03:18:56.629966	\N	\N	City Furniture	\N	f
104	Glock 19	Gen 5 9mm	ADAF456	666.77	\N	2019-05-12	Shooter's Lakeland	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Glock	\N	f
105	Glock 19 OEM Magazine	Gen 5 - 18 round	\N	\N	\N	\N	\N	6	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Glock	\N	f
103	Magpul PMAG 30 Round AR15 Magazine	\N	\N	\N	\N	\N	Palmetto State Armory	13	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Magpul	\N	f
151	Seagate HDD - 5TB	ST5000LM000-2AN170	WCJ49YBN	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-23 02:10:43.830491	\N	\N	Seagate	\N	f
144	CPU Tower Cooler	NH-D15	\N	119.95	\N	2024-11-25	Amazon	1	Replaced failing liquid cooler	Electronics	2024-12-19 09:08:08.932287	\N	\N	Noctua	\N	t
162	ASUS ROG Crosshair VII Hero	 ‎ROG Crosshair VII Hero 	\N	270.00	\N	2018-05-08	Amazon	1	\N	Electronics	2024-12-22 23:13:37.596171	\N	\N	ASUS	\N	f
15	Apple TV 4k Remote	\N	\N	\N	\N	\N	Amazon	2	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	\N	f
119	Arisaka Defense Indexer M-Lok Aluminum	\N	\N	\N	\N	\N	\N	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Arisaka Defense	\N	f
125	Heywood Wakefield Tambour Door Utility Case - Antique	Teak	\N	0.00	1500.00	\N	\N	1	https://www.1stdibs.com/furniture/storage-case-pieces/cabinets/tambour-storage-cabinet-heywood-wakefield/id-f_3087972/ - Gift from my mom	Furniture	2024-12-19 03:18:56.629966	\N	\N	Heywood Wakefield	\N	f
53	1U Rack Shelf	\N	\N	\N	\N	\N	Amazon	1	19" Server Rack Rails Adjustable Universal Rails	Electronics	2024-12-19 02:56:03.547032	\N	\N	StarTech	\N	t
6	MacBook Air	Z18U000K3LL/A	GQ5VK7C60D	\N	\N	2023-01-01	Apple	1	M2 512GB 16GB	Electronics	2024-12-19 02:56:03.547032	\N	\N	Apple	Chase Business Cash	t
137	Yamaha Acoustic Guitar	FG800	\N	350.00	\N	\N	Carlton	1	\N	Guitars	2024-12-19 03:35:52.936752	\N	\N	Yamaha	\N	f
47	EVGA NVIDIA 1080ti SC Gaming Black	EVGTX1080SCB	\N	945.00	\N	2018-04-22	B&H Photo	1	Video Card	Electronics	2024-12-19 02:56:03.547032	\N	\N	EVGA	\N	t
80	LBM 1911 Tailored Fit Navy Cotton Blazer	\N	\N	800.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	LBM	\N	f
77	Meyer Blue Trousers	Exclusive	\N	300.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Meyer	\N	f
33	Samsung 970 EVO Plus	500GB	\N	\N	\N	\N	Amazon	1	M.2 NVMe SSD	Electronics	2024-12-19 02:56:03.547032	\N	\N	Samsung	\N	t
85	Spier and Mackay Custom Striped OCBD	\N	\N	75.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
101	Spier and Mackay Off White Short Sleeve Polo Shirt Collar	\N	\N	38.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
17	Audio-Technica ATH-M50x	Professional Studio	\N	119.57	\N	2018-07-18	Amazon	1	Professional Studio Headphones	Electronics	2024-12-19 02:56:03.547032	\N	\N	Audio Technica	\N	t
95	Spier and Mackay Light Blue Striped Oxford	\N	\N	68.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
96	Spier and Mackay White Ivory Oxford Dress Shirt	\N	\N	58.00	\N	\N	Spier and Mackay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Spier and Mackay	\N	f
84	Brioni Light Weight Wool Trousers	\N	\N	500.00	\N	\N	eBay	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Brioni	\N	f
130	Alontay 7 Drawer Double Dresser by Union Rustic	Walnut	\N	440.00	\N	\N	Wayfair	1	\N	Furniture	2024-12-19 03:18:56.629966	\N	\N	Alontay	\N	f
76	Meyer Dark Navy Trousers	Bonn	\N	300.00	\N	\N	Kirby's Menswear	1	\N	Clothing	2024-12-19 03:10:32.649523	\N	\N	Meyer	\N	f
28	TP-Link EAP660 HD	\N	\N	\N	\N	\N	Amazon	1	Wireless Access Point WiFi 6 AX3600	Electronics	2024-12-19 02:56:03.547032	\N	\N	TP-Link	\N	f
7	ROG Swift Monitor	PG279Q	\N	\N	\N	2018-05-03	Amazon	2	Second one purchased from Marcel for $300	Electronics	2024-12-19 02:56:03.547032	\N	\N	ASUS	\N	t
145	Logitech MX Master 3S Mac	910-006569 	AZ:5PGZFZRHEBHNBFKESKWTOJ1X7Y 	99.50	\N	2023-11-07	Amazon	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	Logitech	\N	t
146	Keychron V10 Max Wireless Mechanical Keyboard	V10M-D4	\N	114.00	\N	2024-11-17	Keychron	1	Alice layout keyboard	Electronics	2024-12-19 09:28:56.570348	\N	\N	Keychron	Amex BBP	t
147	Protectli Vault Firewall	FW4B-0-8-120	\N	319.00	\N	2024-12-08	Amazon	1	Intel Quad Core, AES-NI, 8GB RAM, 120GB mSATA SSD	Electronics	2024-12-19 09:31:24.67157	\N	\N	Protectli	Amex BBP	t
165	Dell R720 Server	PowerEdge R720	G1CWX12	\N	\N	2024-12-29	Elaine	1	2x Xeon E5-2670, 384GB RAM - Purchased in lot of various electronics	Electronics	2024-12-31 14:31:27.536784	\N	\N	Dell	Cash	t
164	Dell R720 Server	PowerEdge R720	CZGNMV1	390.53	\N	2022-05-16	eBay	1	2x Xeon E5-2640, 192GB RAM	Electronics	2024-12-31 14:27:25.841907	\N	\N	Dell	Citi DoubleCash	t
166	Crucial 1TB SSD	CT1000MX500SSD1	1903E1E4D3E1	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
109	Smith and Wesson Model .38sp Handgun	\N	D732219	\N	\N	\N	Amazon	1	\N	Firearms	2024-12-19 03:18:09.095399	\N	\N	Smith and Wesson	\N	f
167	Crucial 1TB SSD	CT1000MX500SSD1	1903E1E4D0D6	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
152	Seagate HDD - 5TB	ST5000LM000-2AN170	WCJ44ZA7	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-23 02:10:46.953511	\N	\N	Seagate	\N	f
168	Crucial 1TB SSD	CT1000MX500SSD1	2203E5FEBC36	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
153	Seagate HDD - 5TB	ST5000LM000-2AN170	WCJ4L9DN	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-23 02:10:50.187484	\N	\N	Seagate	\N	f
150	Seagate HDD - 5TB	ST5000LM000-2AN170	WCJ516BK	\N	\N	\N	Amazon	1	\N	Electronics	2024-12-23 02:10:37.804566	\N	\N	Seagate	\N	f
169	Crucial 1TB SSD	CT1000MX500SSD1	2138E5D3C819	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
170	Crucial 1TB SSD	CT1000MX500SSD1	2138E5D3C813	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
171	Crucial 1TB SSD	CT1000MX500SSD1	2138E5D42E35	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
154	Peak Design Tech Pouch (Midnight)	 ‎ BTP-MN-2	\N	59.95	\N	2023-12-25	Peak Design	1	\N	Homegoods	2024-12-23 03:47:36.75753	\N	\N	Peak Design	\N	f
155	Western Digital WD Red Pro	WD141KFGX	9LHS06MG	\N	\N	\N	Amazon	1	NAS HDD	Electronics	2024-12-23 03:52:00.914394	\N	\N	Western Digital	\N	f
172	Crucial 1TB SSD	CT1000MX500SSD1	2203E5FEBA9D	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
21	WASDv3 Mechanical Keyboard	Cherry MX Brown	\N	150.00	\N	\N	WASD	1	\N	Electronics	2024-12-19 02:56:03.547032	\N	\N	WASD	\N	t
49	Trident Z RGB Series Memory	F4-3600C18D-32GTZ 	\N	153.00	\N	2021-12-03	Amazon	1	32GB (2x16GB) DDR4 RAM Kit	Electronics	2024-12-19 02:56:03.547032	\N	\N	G.Skill	\N	t
158	AMD Ryzen 2700X	YD270XBGAFBOX	\N	329.99	\N	2018-04-21	Newegg	1	\N	Electronics	2024-12-22 23:10:49.283269	\N	\N	AMD	\N	f
159	Fractal Design Define Case	Define R6	\N	149.99	\N	2018-04-21	Newegg	1	\N	Electronics	2024-12-22 23:10:49.295507	\N	\N	Fractal Design	\N	f
160	NVIDIA 1080Ti	EVGTX1080SCB	\N	945.89	\N	2018-04-22	B&H Photo	1	\N	Electronics	2024-12-22 23:10:49.30972	\N	\N	EVGA	\N	f
161	NVIDIA RTX 3060	 ‎GeForce RTX 3060 VENTUS 2X 12G OC 	\N	285.00	\N	2024-08-26	Amazon	1	\N	Electronics	2024-12-22 23:10:49.322146	\N	\N	MSI	Amex MR	f
156	AMD Ryzen 7 5700X3D	100-100001503WOF	\N	209.96	\N	2024-08-04	Amazon	1	\N	Electronics	2024-12-22 23:06:45.484202	\N	\N	AMD	Amex MR	f
173	Crucial 1TB SSD	CT1000MX500SSD1	2203E5FECF5F	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
174	Crucial 1TB SSD	CT1000MX500SSD1	1850E1DDC3A3	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 14:34:04.701253	\N	\N	Crucial	Cash	t
175	Seagate Ironwolf 2TB HDD	ST2000LM015-2E8174	WDZ3X4B2	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 09:41:44.10522	\N	\N	Seagate	Cash	t
176	Seagate Ironwolf 2TB HDD	ST2000LM015-2E8174	WDZ3X191	\N	\N	2024-12-29	Elaine	1	Purchased in lot of various electronics	Electronics	2024-12-31 09:41:44.110735	\N	\N	Seagate	Cash	t
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, created_at) FROM stdin;
1	rt	rusty@rtyner.com	2024-12-19 02:49:33.96773
\.


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_id_seq', 176, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_inventory_brand; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_brand ON public.inventory USING btree (brand_name);


--
-- Name: idx_inventory_item_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_item_name ON public.inventory USING btree (item_name);


--
-- Name: idx_inventory_purchasemethod; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_purchasemethod ON public.inventory USING btree (purchase_method);


--
-- Name: idx_inventory_serial_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_serial_number ON public.inventory USING btree (serial_number);


--
-- Name: inventory_files inventory_files_update; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE inventory_files_update AS
    ON UPDATE TO public.inventory_files DO INSTEAD  UPDATE public.inventory SET picture_path = new.picture_path, invoice_path = new.invoice_path
  WHERE (inventory.id = old.id);


--
-- Name: TABLE inventory_files; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.inventory_files TO PUBLIC;


--
-- PostgreSQL database dump complete
--

